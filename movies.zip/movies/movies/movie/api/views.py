from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.viewsets import ViewSet,ModelViewSet
from rest_framework.response import Response
from .serializer import MovieSerializer,UserSerializer,ReviewSerializer
from .models import MovieList,Review
from rest_framework import status,authentication,permissions
from rest_framework.decorators import action

# Create your views here.

class UserView(APIView):
   def post(self,request,*args,**kwargs):
      ser=UserSerializer(data=request.data)
      if ser.is_valid():
         ser.save()
         return Response({"msg":"Registered"})
      else:
         return Response({"msg":ser.errors},status=status.HTTP_404_NOT_FOUND)

class MovieView(ModelViewSet):
   serializer_class=MovieSerializer
   model=MovieList
   queryset=MovieList.objects.all()
   authentication_classes=[authentication.TokenAuthentication]
   permission_classes=[permissions.IsAuthenticated]

@action(detail=True,methods=['get'])
def get_review(self,request,*args,**kwargs):
   id=kwargs.get('pk')
   item=MovieList.objects.get(id=id)
   reviews=Review.objects.filter(movie=item)
   ser=ReviewSerializer(reviews,many=True)
   return Response(data=ser.data)

@action(detail=True,methods=['post'])
def add_review(self,request,*args,**kwargs):
   id=kwargs.get('pk')
   item=MovieList.objects.get(id=id)
   user=request.user
   ser=ReviewSerializer(data=request.data,context={"user":user,"movie":item})
   if ser.is_valid():
      ser.save()
      return Response({"msg":"OK"})
   else:
      return Response({"msg":ser.errors},status=status.HTTP_404_NOT_FOUND)