from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class MovieList(models.Model):
    name=models.CharField(max_length=100)
    director=models.CharField(max_length=100)
    year=models.IntegerField()
    genera=models.CharField(max_length=100)

class Review(models.Model):
    review=models.CharField(max_length=100)
    rating=models.FloatField()
    movie=models.ForeignKey(MovieList,on_delete=models.CASCADE)
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    class Meta:
        unique_together=('user','movie')