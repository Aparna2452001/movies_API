from rest_framework import serializers
from .models import MovieList,Review
from django.contrib.auth.models import User
# from django.contrib.auth.models import User

class MovieSerializer(serializers.ModelSerializer):
    class Meta:
        model=MovieList
        fields="__all__"


    
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=["username","password","email"]
        def create(self,validated_data):
            return User.objects.create_user(**validated_data)

class MovieNameSer(serializers.ModelSerializer):
    class Meta:
        model=MovieList
        fields=['name']

class UserNameSer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=['username']

class ReviewSerializer(serializers.ModelSerializer):
    movie=MovieNameSer(many=False,read_only=True)
    user=UserNameSer(many=False,read_only=True)
    class Meta:
        model=Review
        fields=["review","rating","movie","user"]
    def create(self, validated_data):
        user=self.context.get("user")
        movie=self.context.get("movie")
        return Review.objects.create(user=user,movie=movie,**validated_data)